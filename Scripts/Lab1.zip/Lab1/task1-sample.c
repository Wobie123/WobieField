/* task1-sample.c */
#include <stdio.h>
#include <string.h>
#include <openssl/bn.h>

#define NBITS 256

void printBN(char *msg, BIGNUM *a)
{
    /* Use BN_bn2hex(a) for hex string
    * Use BN_bn2dec(a) for decimal string */
    char *number_str = BN_bn2hex(a);
    printf("%s %s\n", msg, number_str);
    OPENSSL_free(number_str);
}

void string2hex(char*string,char* hex){
    int loop = 0;
    int i = 0;
    while(string[loop] != '\0'){
        sprintf((char*)(hex+i),"%02X", string[loop]);//change each letter to hex
        loop+=1;
        i+=2;
    }
    hex[i+=1] = '\0';//when string ends
}

int hex2int(char c){
    int first = c / 16 - 3;
    int second = c % 16;
    int result = first*10 + second;
    if(result > 9) result--;
    return result;
}

int hex2ascii(char a, char b){
    int high = hex2int(a)*16;
    int low = hex2int(b);
    return high+low;
}

int main()
{
    /*
    default
    p = F7E75FDC469067FFDC4E847C51F452DF 
    q = E85CED54AF57E53E092113E62F436F4F
    e = 0D88C3
    */

    // Declare the required variables
    BN_CTX *ctx = BN_CTX_new();
    BIGNUM *p = BN_new();
    BIGNUM *q = BN_new();
    BIGNUM *e = BN_new();
    BIGNUM *n = BN_new();
    BIGNUM *d = BN_new();
    BIGNUM *c = BN_new();
    BIGNUM *C = BN_new();
    //BIGNUM *m = BN_new();
    BIGNUM *h = BN_new();//hex
    BIGNUM *M = BN_new();//Message
    BIGNUM *s = BN_new();//secret key
    BIGNUM *one = BN_new();
    BIGNUM *q_1 = BN_new();
    BIGNUM *p_1 = BN_new();
    BIGNUM *phi_n = BN_new();

    // Convert hex string to BIGNUM by calling the BN_hex2bn function
    BN_hex2bn(&p, "E58C03FCD2A442B9D249529CE3D8C063");
    BN_hex2bn(&q, "F4ED8CA1303197784223D600C0BC716F");
    BN_hex2bn(&e, "FE61BF");
    BN_hex2bn(&one, "01"); // 1 stored as BIGNUM

    //Task 1 ----------------------------------------------------------------------------------------
    printf("task1\n");
    //Calculate n
    //n = p * q
    BN_mul(n,p,q,ctx);//p*q store in n
    printBN("n =", n);
    //Calculate Phi
    //phi(n) = (p-1)*(q-1)
    BN_sub(q_1,p,one);
    BN_sub(p_1,q,one);
    BN_mul(phi_n,p_1,q_1,ctx);//store in phi(n)
    printBN("phi_n = ", phi_n);
    //Calculate d by calling the BN_mod_inverse function
    //(d)*(e) mod phi(n) = 1
    BN_mod_inverse(d,e,phi_n,ctx);
    printBN("d = ", d);

    //Task 2------------------------------------------------------------------------------------------
    printf("\ntask2\n");
    
    char ch;
    char string[12];
    
    FILE* fileopen;//opens the file
    fileopen = fopen("task2.txt", "r");
     if (NULL == fileopen) {
        printf("file can't be opened \n");
    }

    for(int i = 0;i< 4; i = i+1){//get to message
        ch = fgetc(fileopen);
    }

    for(int i =0;i<12;i = i+1){//grab message
        string[i] = fgetc(fileopen);
    }
    string[12] = '\0';//to close string
    fclose(fileopen);
    
    //char*string = fileopener("task2.txt",12);
    printf("string: %s\n",string);
    int len = strlen(string);
    char hex_str[(len*2)+1];

    string2hex(string,hex_str);//function
    printf("hex_str: %s\n",hex_str);
    BN_hex2bn(&c,hex_str);
    BN_mod_exp(C,c,e,n,ctx);
    printBN("encryption = ", C);
    //Task 3------------------------------------------------------------------------------------------
    printf("\ntask3\n");
    char *chr;
    char encrypt[64];

    //FILE* fileopen;//opens the file
    fileopen = fopen("task3.txt", "r");
     if (NULL == fileopen) {
        printf("file can't be opened \n");
    }

    for(int i = 0;i< 4; i = i+1){//get to message
        ch = fgetc(fileopen);
    }

    for(int i =0;i<64;i = i+1){//grab message
        encrypt[i] = fgetc(fileopen);
    }
    encrypt[64] = '\0';
    fclose(fileopen);
    

    printf("encrypted string %s\n", encrypt);//encrypt string
    
    BN_hex2bn(&c, encrypt);
    BN_mod_exp(h,c,d,n,ctx);
    printBN("hexi = ", h);
    chr = BN_bn2hex(h);
    
    len = strlen(chr);
    char hex =0;
    printf("Decypher to: ");
    for(int i =0;i<len;i+=1){
        if(i%2!=0){//take 2 values to turn into ascii txt
            printf("%c", hex2ascii(hex, chr[i]));//prints one char at a time
        }else{
            hex = chr[i];
        }
    }
    printf("\n");
    //Task 4------------------------------------------------------------------------------------------
    printf("\ntask4\n");
    char Message[13];

    //FILE* fileopen;//opens the file
    fileopen = fopen("task4.txt", "r");
     if (NULL == fileopen) {
        printf("file can't be opened \n");
    }

    for(int i = 0;i< 4; i = i+1){//get to message
        ch = fgetc(fileopen);
    }

    for(int i =0;i<13;i = i+1){//grab message
        Message[i] = fgetc(fileopen);
    }
    Message[13] = '\0';
    fclose(fileopen);
    printf("Message string %s\n", Message);
    
    BN_hex2bn(&M, Message);
    BN_mod_exp(s,M,d,n,ctx);
    printBN("Signature is: ", s);
    
    //Task 5------------------------------------------------------------------------------------------
    printf("\ntask5\n");
    //BN_hex2bn(&M, "Hello world!"); Correct message sent
    BN_hex2bn(&s, "DE73C0EFAEFEF2B2A8440B87C54E79C52601DFA8969B283A7A76DD4520555F12");
    BN_hex2bn(&e, "CB6603");
    BN_hex2bn(&n, "E5A8C4C7A182E28066330C5D6D997BCC8BDE49A957D3B4959431955A1017F2A5");
    
    BN_mod_exp(M,s,e,n,ctx);
    printBN("verify = ", M);
    chr = BN_bn2hex(M);
    
    len = strlen(chr);//reused variables 
    hex =0;
    printf("Decypher to: ");
    for(int i =0;i<len;i+=1){
        if(i%2!=0){//take 2 values to turn into ascii txt
            printf("%c", hex2ascii(hex, chr[i]));//prints one char at a time
        }else{
            hex = chr[i];
        }
    }
    printf("\n");
    return 0;
}
